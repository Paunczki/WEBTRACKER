This is the Firefox extension part
Download Link: 

If you have any questions find a way to reach out to me
I can update this as it goes

To view messages, you must open firefox's developer's console
